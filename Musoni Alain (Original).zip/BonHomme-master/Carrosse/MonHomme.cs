﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Threading;

namespace Carrosse
{
    class MonHomme : MonRecTournant
    {
        private MonCercle head,eye;
        private MonRectangle mouth ;
        private MonBras armG, armD;
        private MaJambe legD,legG;
        private PlayGround playground;

        public MonHomme(PictureBox hebergeur, int xsg, int ysg, int longueur, int hauteur) : base(hebergeur, xsg/6, (ysg*4)-20, longueur-20, (hauteur/2)+10,0)
        {
            this.playground = new PlayGround(hebergeur, xsg, ysg, longueur, hauteur,Angle, Color.Black, Color.Teal);
            this.head = new MonCercle(hebergeur, (xsg+longueur)/5, (ysg + hauteur * 2)+19 , hauteur / 4, Color.Brown, Color.Chocolate);
            this.eye = new MonCercle(hebergeur, (xsg + longueur)/4, (ysg + hauteur * 2)+19, hauteur / 25, Color.Black, Color.White);
            this.mouth = new MonRectangle(hebergeur, (xsg + longueur+15)/5 , (ysg + hauteur * 2)+25, Longueur / 10, hauteur / 50,Color.White);
            this.armD = new MonBras(hebergeur, (xsg + longueur) / 6, (ysg + hauteur * 2) + 35, Longueur / 2, hauteur / 2, 0,Color.Black);
            this.armG = new MonBras(hebergeur, (xsg + longueur) / 6, (ysg + hauteur*2)+35, Longueur / 2, hauteur/2,0,Color.Black);
            this.legD = new MaJambe(hebergeur, (xsg + longueur+5) / 7, ysg + hauteur*3, Longueur / 2, hauteur / 2,0,Color.Black);
            this.legG = new MaJambe(hebergeur, (xsg + longueur+5) / 7, ysg + hauteur*3, Longueur / 2, hauteur / 2,0,Color.Black);
            
        }

        public void Bouger(int deplX, int deplY, double ABGH, double ABGB, double ABDH, double ABDB, double AJGH, double AJGB, double AJDH, double AJDB)
        {
            base.Bouger(deplX, deplY);
            this.eye.Bouger(deplX, deplY);
            this.mouth.Bouger(deplX, deplY);
            this.head.Bouger(deplX, deplY);
            this.armD.Bouger(deplX, deplY,ABDH,ABDB);
            this.armG.Bouger(deplX, deplY, ABGH, ABGB);
            this.legG.Bouger(deplX, deplY,  AJGH, AJGB);
            this.legD.Bouger(deplX, deplY,  AJDH, AJDB);
            this.playground.Bouger(deplX, deplY);

        }
        public new void Cacher(IntPtr handle)
        {
            base.Cacher(handle);
            this.eye.Cacher(handle);
            this.mouth.Cacher(handle);
            this.head.Cacher(handle);
            this.armD.Cacher(handle);
            this.armG.Cacher(handle);
            this.legD.Cacher(handle);
            this.legG.Cacher(handle);
            this.playground.Cacher(handle);
        }
        public new void Afficher(IntPtr handle)
        {
            this.playground.Afficher(handle);
            this.head.Afficher(handle);
            this.eye.Afficher(handle);
            this.mouth.Afficher(handle);
            this.armG.Afficher(handle);
            this.legG.Afficher(handle);
            base.Afficher(handle);
            this.legD.Afficher(handle);
            this.armD.Afficher(handle);
        }
        // animating function
        public void Marcher(int depX, int depY, IntPtr handle)
        {

            //                      //ajdB - ajdH - ajgB - ajgH  - abdB - abdH - abgB - abgH - aBase
            MakeMovement(0, depY, -0.01, 0.02, -0.04, -0.02, 0.01, -0.02, 0.04, 0.01, -0.01, -1, 0, handle);
            MakeMovement(0, depY, -0.02, 0.06, -0.07, -0.04, 0.02, -0.04, 0.06, 0.02, -0.02, -1, 0, handle);
            MakeMovement(0, depY, -0.03, 0.08, -0.10, -0.06, 0.03, -0.06, 0.08, 0.03, -0.03, -1, 0, handle);
            MakeMovement(0, depY, -0.04, 0.10, -0.13, -0.08, 0.04, -0.08, 0.10, 0.04, -0.04, -1, 0, handle);
            MakeMovement(0, depY, -0.05, 0.12, -0.16, -0.10, 0.05, -0.10, 0.12, 0.05, -0.05, -1, 0, handle);
            MakeMovement(0, depY, -0.06, 0.14, -0.19, -0.12, 0.06, -0.12, 0.14, 0.06, -0.06, -1, 0, handle);

            //one step
            //                     //ajdB - ajdH - ajgB - ajgH - abdB - abdH - abgB-abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, 0.02, -0.02, -0.01, -0.04, -0.01, -0.02, 0.05, 0.02,   0, -1, 0, handle);
            MakeMovement(depX, depY, 0.04, -0.06, -0.02, -0.06, -0.02, -0.04, 0.06, 0.03,   0, -1, 0, handle);
            MakeMovement(depX, depY, 0.06, -0.08, -0.03, -0.08, -0.03, -0.06, 0.07, 0.04,   0, -1, 0, handle);
            MakeMovement(depX, depY, 0.08, -0.10, -0.04, -0.10, -0.04, -0.08, 0.08, 0.05,   0, -1, 0, handle);
            MakeMovement(depX, depY, 0.10, -0.12, -0.05, -0.12, -0.05, -0.10, 0.09, 0.06,   0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01, -0.01, -0.08, -0.01, -0.00, -0.10, 0.09, 0.06,   0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01, -0.01, -0.10, -0.01, -0.05, -0.10, 0.09, 0.06,   0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01, -0.01, -0.12, -0.01, -0.05, -0.10, 0.09, 0.06,   0, -1, 0, handle);
            //                     //ajdB - ajdH - ajgB - ajgH - abdB - abdH - abgB-abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, -0.02, 0.02, -0.02, 0.04, 0.01, 0.02, -0.05, -0.02,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.04, 0.06, -0.04, 0.06, 0.02, 0.04, -0.06, -0.03,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.06, 0.08, -0.06, 0.08, 0.03, 0.06, -0.07, -0.04,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.08, 0.10, -0.08, 0.10, 0.04, 0.08, -0.08, -0.05,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.10, 0.12, -0.10, 0.12, 0.05, 0.10, -0.09, -0.06,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, 0.01, -0.12, 0.01, 0.00, 0.10, -0.09, -0.06,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, 0.01, -0.14, 0.01, 0.05, 0.10, -0.09, -0.06,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, 0.01, -0.16, 0.01, 0.05, 0.10, -0.09, -0.06,     0, -1, 0, handle);
            //                     //ajdB - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, -0.01, -0.02, 0.00, 0.04,  0.01,   0.01, -0.01, -0.02,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.02, -0.06, 0.01, 0.06,  0.01,   0.02, -0.01, -0.04,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.03, -0.08, 0.01, 0.08,  0.01,   0.03, -0.01, -0.06,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.04, -0.10, 0.01, 0.10,  0.02,   0.04, -0.02, -0.08,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.05, -0.12, 0.02, 0.12,  0.02,   0.05, -0.02, -0.10,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.06, -0.14, 0.03, 0.14,  0.02,   0.06, -0.02, -0.12,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.07, -0.16, 0.03, 0.16,  0.02,   0.07, -0.02, -0.14,     0, -1, 0, handle);
            MakeMovement(depX, depY, -0.08, -0.18, 0.03, 0.18,  0.02,   0.08, -0.02, -0.16,     0, -1, 0, handle);
            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, -0.00, -0.01, 0.02,   0.01,  0.01, 0.01, 0.01, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.00, -0.01, 0.04,   0.01,  0.02, 0.02, 0.01, -0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.00, -0.01, 0.06,   0.01,  0.03, 0.03, 0.01, -0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, -0.01, 0.08,   0.01,  0.04, 0.04, 0.01, -0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, -0.01, 0.10,   0.01,  0.05, 0.05, 0.01, -0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, -0.01, 0.12,   0.02,  0.06, 0.06, 0.02, -0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, -0.01, 0.14,   0.02,  0.07, 0.07, 0.02, -0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, -0.01, 0.16,   0.02,  0.08, 0.08, 0.02, -0.08, 0, -1, 0, handle);
            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, -0.01,   -0.01,  0.02, -0.01,  0.01, -0.01,  0.01, 0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.02,   -0.01,  0.04, -0.02,  0.01, -0.02,  0.01, 0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.03,   -0.01,  0.06, -0.03,  0.01, -0.03,  0.01, 0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.04,   -0.02,  0.08, -0.04,  0.01, -0.04,  0.01, 0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.05,   -0.02,  0.10, -0.05,  0.02, -0.05,  0.01, 0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.06,   -0.02,  0.12, -0.06,  0.02, -0.06,  0.01, 0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.07,   -0.02,  0.14, -0.07,  0.02, -0.07,  0.02, 0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.08,   -0.02,  0.16, -0.08,  0.02, -0.08,  0.02, 0.08, 0, -1, 0, handle);
            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, 0.01,   0.01, -0.01, -0.01, -0.01, -0.01, 0.01, 0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01,   0.02, -0.01, -0.01, -0.01, -0.02, 0.02, 0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01,   0.03, -0.01, -0.01, -0.01, -0.03, 0.03, 0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01,   0.04, -0.01, -0.01, -0.01, -0.04, 0.04, 0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.02,   0.05, -0.01, -0.01, -0.02, -0.05, 0.05, 0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.02,   0.06, -0.01, -0.01, -0.02, -0.06, 0.06, 0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.02,   0.07, -0.02, -0.01, -0.02, -0.07, 0.07, 0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.02,   0.08, -0.02, -0.01, -0.02, -0.08, 0.08, 0.08, 0, -1, 0, handle);

            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, 0.01,   0.02, -0.01, -0.01,  -0.01, -0.02,  0.01, 0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.02,   0.04, -0.02, -0.02,  -0.02, -0.04,  0.02, 0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.03,   0.06, -0.02, -0.03,  -0.03, -0.06,  0.03, 0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.04,   0.08, -0.02, -0.04,  -0.04, -0.08,  0.04, 0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.05,   0.10, -0.02, -0.05,  -0.05, -0.10,  0.05, 0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.06,   0.12, -0.03, -0.06,  -0.06, -0.12,  0.06, 0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.07,   0.14, -0.03, -0.07,  -0.07, -0.14,  0.07, 0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.08,   0.16, -0.03, -0.08,  -0.08, -0.16,  0.08, 0.08, 0, -1, 0, handle);

            ////                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            //MakeMovement(depX, depY, -0.01,  -0.01,  0.01, -0.01,  -0.01, 0.02, -0.01, -0.01, 0, -1, 0, handle);
            //MakeMovement(depX, depY, -0.02,  -0.01,  0.02, -0.01,  -0.02, 0.04, -0.02, -0.02, 0, -1, 0, handle);
            //MakeMovement(depX, depY, -0.03,  -0.01,  0.02, -0.01,  -0.03, 0.06, -0.03, -0.03, 0, -1, 0, handle);
            //MakeMovement(depX, depY, -0.04,  -0.01,  0.02, -0.01,  -0.04, 0.08, -0.04, -0.04, 0, -1, 0, handle);
            //MakeMovement(depX, depY, -0.05,  -0.01,  0.02, -0.01,  -0.05, 0.10, -0.05, -0.05, 0, -1, 0, handle);
            //MakeMovement(depX, depY, -0.06,  -0.01,  0.03, -0.02,  -0.06, 0.12, -0.06, -0.06, 0, -1, 0, handle);
            //MakeMovement(depX, depY, -0.07,  -0.01,  0.03, -0.02,  -0.07, 0.14, -0.07, -0.07, 0, -1, 0, handle);
            //MakeMovement(depX, depY, -0.08,  -0.01,  0.03, -0.02,  -0.08, 0.16, -0.08, -0.08, 0, -1, 0, handle);

            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, 0.02, -0.01,  -0.01, -0.01,  0.01, 0.01, -0.01, -0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.04, -0.01,  -0.02, -0.01,  0.02, 0.02, -0.02, -0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.08, -0.01,  -0.03, -0.01,  0.03, 0.03, -0.03, -0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.10, -0.01,  -0.04, -0.01,  0.04, 0.04, -0.04, -0.08, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.12, -0.01,  -0.05, -0.01,  0.05, 0.05, -0.05, -0.10, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.14, -0.01,  -0.06, -0.02,  0.06, 0.06, -0.06, -0.12, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.16, -0.01,  -0.07, -0.02,  0.07, 0.07, -0.07, -0.14, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.18, -0.01,  -0.08, -0.02,  0.08, 0.08, -0.08, -0.16, 0, -1, 0, handle);

            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, -0.01, -0.01, -0.01,  0.02,  0.01,  0.02, -0.01, -0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.02, -0.02, -0.02,  0.04,  0.02,  0.04, -0.02, -0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.03, -0.03, -0.03,  0.08,  0.03,  0.06, -0.03, -0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.04, -0.04, -0.04,  0.10,  0.04,  0.08, -0.04, -0.08, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.05, -0.05, -0.05,  0.12,  0.05,  0.10, -0.05, -0.10, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.06, -0.06, -0.06,  0.14,  0.06,  0.12, -0.06, -0.12, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.07, -0.07, -0.07,  0.16,  0.07,  0.14, -0.07, -0.14, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.08, -0.08, -0.08,  0.18,  0.08,  0.16, -0.08, -0.16, 0, -1, 0, handle);

            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, -0.02, -0.02,  0.02, 0.01, - 0.01,  0.01,  0.01,  0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.05, -0.04,  0.04, 0.02, - 0.02,  0.01,  0.02,  0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.08, -0.08,  0.08, 0.03, - 0.03,  0.01,  0.03,  0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.11, -0.10,  0.10, 0.04, - 0.04,  0.01,  0.04,  0.08, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.14, -0.12,  0.12, 0.05, - 0.05,  0.01,  0.05,  0.10, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.17, -0.14,  0.14, 0.06, - 0.06,  0.02,  0.06,  0.12, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.20, -0.16,  0.16, 0.07, - 0.07,  0.02,  0.07,  0.14, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.23, -0.18,  0.18, 0.08, - 0.08,  0.02,  0.08,  0.16, 0, -1, 0, handle);
            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, -0.02,   0.02, -0.01, -0.02, -0.01, -0.02, 0.01, 0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.04,   0.04, -0.02, -0.04, -0.01, -0.04, 0.02, 0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.08,   0.08, -0.03, -0.06, -0.01, -0.06, 0.03, 0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.11,   0.10, -0.04, -0.08, -0.01, -0.08, 0.04, 0.08, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.14,   0.12, -0.05, -0.10, -0.02, -0.10, 0.05, 0.10, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.17,   0.14, -0.06, -0.12, -0.02, -0.12, 0.06, 0.12, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.20,   0.16, -0.07, -0.14, -0.02, -0.14, 0.07, 0.14, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.23,   0.18, -0.08, -0.16, -0.02, -0.16, 0.08, 0.16, 0, -1, 0, handle);

            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, 0.02,   0.03, -0.01, -0.01,  0.01, 0.02, -0.01, -0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.04,   0.06, -0.01, -0.02,  0.01, 0.04, -0.02, -0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.08,   0.09, -0.01, -0.03,  0.01, 0.06, -0.03, -0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.10,   0.11, -0.02, -0.04,  0.01, 0.08, -0.04, -0.08, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.12,   0.13, -0.02, -0.05,  0.02, 0.10, -0.05, -0.10, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.14,   0.16, -0.02, -0.06,  0.02, 0.12, -0.06, -0.12, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.16,   0.19, -0.02, -0.07,  0.02, 0.14, -0.07, -0.14, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.18,   0.21, -0.02, -0.08,  0.02, 0.16, -0.08, -0.16, 0, -1, 0, handle);

            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY-4, 0.01,  -0.02, -0.01,  0.02, -0.01, -0.02, 0.01, 0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY-4, 0.01,  -0.04, -0.01,  0.04, -0.01, -0.04, 0.02, 0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY-4, 0.01,  -0.06, -0.01,  0.06, -0.01, -0.06, 0.03, 0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY-4, 0.01,  -0.08, -0.01,  0.08, -0.01, -0.08, 0.04, 0.08, 0, -1, 0, handle);
            MakeMovement(depX, depY-4, 0.02,  -0.10, -0.01,  0.10, -0.02, -0.10, 0.05, 0.10, 0, -1, 0, handle);
            MakeMovement(depX, depY-4, 0.02,  -0.12, -0.01,  0.12, -0.02, -0.12, 0.06, 0.12, 0, -1, 0, handle);
            MakeMovement(depX, depY-4, 0.02,  -0.14, -0.02,  0.14, -0.02, -0.14, 0.07, 0.14, 0, -1, 0, handle);
            MakeMovement(depX, depY-4, 0.02,  -0.16, -0.02,  0.16, -0.02, -0.16, 0.08, 0.16, 0, -1, 0, handle);

            //                         //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY - 4, 0.00,   0.00, 0.00, 0.00, 0.00, 0.00, -0.01, -0.00, 0, -1, 0, handle);
            MakeMovement(depX, depY - 4, 0.00,   0.00, 0.00, 0.00, 0.00, 0.00, -0.02, -0.00, 0, -1, 0, handle);
            MakeMovement(depX, depY - 4, 0.00,   0.00, 0.00, 0.00, 0.00, 0.00, -0.03, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 4, 0.00,   0.00, 0.00, 0.00, 0.00, 0.00, -0.04, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 4, 0.00,   0.00, 0.00, 0.00, 0.00, 0.00, -0.05, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 4, 0.00,   0.00, 0.00, 0.00, 0.00, 0.00, -0.06, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 4, 0.00,   0.00, 0.00, 0.00, 0.00, 0.00, -0.07, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 4, 0.00,   0.00, 0.00, 0.00, 0.00, 0.00, -0.08, -0.01, 0, -1, 0, handle);

            MakeMovement(depX, depY - 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.01, -0.00, 0, -1, 0, handle);
            MakeMovement(depX, depY - 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.02, -0.00, 0, -1, 0, handle);
            MakeMovement(depX, depY - 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.03, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.04, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.05, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.06, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.07, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY - 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.08, -0.01, 0, -1, 0, handle);

            MakeMovement(depX, depY + 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.01, -0.00, 0, -1, 0, handle);
            MakeMovement(depX, depY + 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.02, -0.00, 0, -1, 0, handle);
            MakeMovement(depX, depY + 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.03, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY + 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.04, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY + 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.05, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY + 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.06, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY + 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.07, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY + 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, -0.08, -0.01, 0, -1, 0, handle);

            MakeMovement(depX, depY + 4, 0.01, -0.01, -0.01, 0.01, -0.01, -0.01, 0.02, 0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY + 4, 0.01, -0.02, -0.01, 0.02, -0.02, -0.02, 0.04, 0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY + 4, 0.01, -0.03, -0.01, 0.03, -0.03, -0.03, 0.06, 0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY + 4, 0.02, -0.04, -0.01, 0.04, -0.04, -0.04, 0.08, 0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY + 4, 0.02, -0.05, -0.01, 0.05, -0.05, -0.05, 0.10, 0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY + 4, 0.02, -0.06, -0.02, 0.06, -0.06, -0.06, 0.12, 0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY + 4, 0.02, -0.07, -0.02, 0.07, -0.07, -0.07, 0.14, 0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY + 4, 0.02, -0.08, -0.02, 0.08, -0.08, -0.08, 0.16, 0.08, 0, -1, 0, handle);

            //                         //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY,     0.03,  0.01,  0.02, -0.01, -0.01, 0.02, -0.01, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY,     0.05,  0.02,  0.04, -0.02, -0.02, 0.04, -0.01, -0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY,     0.07,  0.03,  0.06, -0.03, -0.03, 0.06, -0.01, -0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY,     0.09,  0.04,  0.08, -0.04, -0.04, 0.08, -0.01, -0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY,     0.11,  0.05,  0.10, -0.05, -0.05, 0.10, -0.01, -0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY,     0.13,  0.06,  0.12, -0.06, -0.06, 0.12, -0.01, -0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY,     0.15,  0.07,  0.14, -0.07, -0.07, 0.14, -0.02, -0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY,     0.17,  0.08,  0.16, -0.08, -0.08, 0.16, -0.02, -0.08, 0, -1, 0, handle);
            //                         //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY+2, -0.01,   -0.02,  0.02,  0.01, -0.01, -0.02, -0.01, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY+2, -0.02,   -0.04,  0.04,  0.02, -0.02, -0.04, -0.02, -0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY+2, -0.03,   -0.06,  0.06,  0.03, -0.03, -0.06, -0.03, -0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY+2, -0.04,   -0.08,  0.08,  0.04, -0.04, -0.08, -0.04, -0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY+2, -0.05,   -0.10,  0.10,  0.05, -0.05, -0.10, -0.05, -0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY+2, -0.06,   -0.12,  0.12,  0.06, -0.06, -0.12, -0.06, -0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY+2, -0.07,   -0.14,  0.14,  0.07, -0.07, -0.14, -0.07, -0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY+2, -0.08,   -0.16,  0.16,  0.08, -0.08, -0.16, -0.08, -0.08, 0, -1, 0, handle);

            //                      //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY +1, 0.01,   0.02, -0.01, -0.02, 0.01, 0.02, -0.01, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY +1, 0.01,   0.04, -0.02, -0.04, 0.02, 0.04, -0.02, -0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY +1, 0.01,   0.06, -0.03, -0.06, 0.03, 0.06, -0.03, -0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY +1, 0.01,   0.08, -0.04, -0.08, 0.04, 0.08, -0.04, -0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY ,   0.01,   0.10, -0.05, -0.10, 0.05, 0.10, -0.05, -0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY ,   0.02,   0.12, -0.06, -0.12, 0.06, 0.12, -0.06, -0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY ,   0.02,   0.14, -0.08, -0.14, 0.07, 0.14, -0.07, -0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY ,   0.02,   0.16, -0.10, -0.16, 0.08, 0.16, -0.08, -0.08, 0, -1, 0, handle);

            //                      //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, -0.01, -0.02,  -0.01,  0.02,  0.01, 0.01, -0.01, -0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, -0.04,  -0.02,  0.04,  0.02, 0.02, -0.02, -0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, -0.06,  -0.03,  0.06,  0.03, 0.03, -0.03, -0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, -0.08,  -0.04,  0.08,  0.04, 0.04, -0.04, -0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.01, -0.10,  -0.05,  0.10,  0.05, 0.05, -0.05, -0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.02, -0.12,  -0.06,  0.12,  0.06, 0.06, -0.06, -0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.02, -0.14,  -0.08,  0.14,  0.07, 0.07, -0.07, -0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.02, -0.16,  -0.10,  0.16,  0.08, 0.08, -0.08, -0.08, 0, -1, 0, handle);


            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, -0.01,   0.02, -0.01, -0.02, 0.01, 0.01, 0.01, 0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.02,   0.04, -0.02, -0.04, 0.02, 0.02, 0.02, 0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.03,   0.06, -0.03, -0.06, 0.03, 0.03, 0.03, 0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.04,   0.08, -0.04, -0.08, 0.04, 0.04, 0.04, 0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.05,   0.10, -0.05, -0.10, 0.05, 0.05, 0.05, 0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.06,   0.12, -0.06, -0.12, 0.06, 0.06, 0.06, 0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.07,   0.14, -0.08, -0.14, 0.07, 0.07, 0.07, 0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY, -0.08,   0.16, -0.10, -0.16, 0.08, 0.08, 0.08, 0.08, 0, -1, 0, handle);

            //                     //ajdB  - ajdH - ajgB - ajgH - abdB - abdH - abgB - abgH - aBase - posPx-posPy
            MakeMovement(depX, depY, 0.01, -0.01, 0.01, 0.01, -0.01, -0.01,  -0.01, 0.01, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01, -0.02, 0.02, 0.02, -0.01, -0.02,  -0.02, 0.02, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01, -0.03, 0.03, 0.03, -0.01, -0.03,  -0.03, 0.03, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01, -0.04, 0.04, 0.04, -0.02, -0.04,  -0.04, 0.04, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01, -0.05, 0.05, 0.05, -0.02, -0.05,  -0.05, 0.05, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.01, -0.06, 0.06, 0.06, -0.02, -0.06,  -0.06, 0.06, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.02, -0.07, 0.08, 0.07, -0.02, -0.07,  -0.07, 0.07, 0, -1, 0, handle);
            MakeMovement(depX, depY, 0.02, -0.08, 0.10, 0.08, -0.02, -0.08,  -0.08, 0.08, 0, -1, 0, handle);

        }
        public void MakeMovement(int depX, int depY, double AJDG, double AJDD, double AJGG, double AJGD, double ABDG, double ABDD, double ABGG, double ABGD, double ABASE,int posPlayX,int posPayY, IntPtr handle)
        {
            Thread.Sleep(10);
            Cacher(handle);
            this.armG.Bouger(depX, depY,ABGD,ABGG);
            this.legG.Bouger(depX, depY, AJGD, AJGG);
            base.Bouger(depX, depY,ABASE);
            this.head.Bouger(depX, depY);
            this.eye.Bouger(depX, depY);
            this.mouth.Bouger(depX, depY);
            this.legD.Bouger(depX, depY, AJDD, AJDG);
            this.armD.Bouger(depX, depY, ABDD, ABDG);
            this.playground.Bouger(posPlayX, posPayY);
            Afficher(handle);
            Thread.Sleep(10);
        }
    }
}
