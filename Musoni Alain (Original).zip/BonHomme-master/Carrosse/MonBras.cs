﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;


namespace Carrosse
{
    class MonBras : MonRecTournant
    {
        #region Données membres
        //private bool _Remplir = true;
        //private int _Hauteur = 1;
        //private int _Longueur = 1;
        private MonRecTournant avbras, main;
        #endregion

        #region Constructeurs
        public MonBras(PictureBox hebergeur, int xsg, int ysg, int longueur, int hauteur, double angle,Color pot) : base(hebergeur, xsg, ysg,longueur-4,hauteur-15)
        {
            this.avbras = new MonRecTournant(hebergeur, xsg, ysg+hauteur/2 , longueur-6, hauteur-13,angle, Color.Chocolate,Color.Black);
            this.main = new MonRecTournant(hebergeur, xsg, ysg + hauteur+8 , longueur-5, hauteur / 4,angle, Color.Coral ,Color.Black);
        }
        #endregion
        #region Méthodes
        public  void Bouger(int deplX, int deplY,double ah,double ab)
        {
            base.Bouger(deplX, deplY,ah);
            this.avbras.X = base.CIG.X;
            this.avbras.Y = base.CIG.Y;
            avbras.Bouger(0, 0, ab);
            avbras.Bouger(base.CIM.X - avbras.CSM.X, base.CIM.Y - avbras.CSM.Y,0);
            this.main.X = this.avbras.CIG.X;
            this.main.Y = this.avbras.CIG.Y;
            main.Bouger(0, 0, ab);
            main.Bouger(avbras.CIM.X - main.CSM.X, avbras.CIM.Y - main.CSM.Y, 0);

        }

        public new void Cacher(IntPtr handle)
        {
            base.Cacher(handle);
            this.avbras.Cacher(handle);
            this.main.Cacher(handle);
           
        }

        public new void Afficher(IntPtr handle)
        {
            this.avbras.Afficher(handle);
            base.Afficher(handle);
            this.main.Afficher(handle);
            
        }
        #endregion
    }

}
