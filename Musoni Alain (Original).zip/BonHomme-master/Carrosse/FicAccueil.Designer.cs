﻿namespace Carrosse
{
    partial class EcranAccueil
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TV = new System.Windows.Forms.PictureBox();
            this.timerImage = new System.Windows.Forms.Timer(this.components);
            this.btnEffacer = new System.Windows.Forms.Button();
            this.btnStopDeplacerCTick = new System.Windows.Forms.Button();
            this.btnCreationCarrosse = new System.Windows.Forms.Button();
            this.cHomme = new System.Windows.Forms.Button();
            this.btnMarcher = new System.Windows.Forms.Button();
            this.btnJouer = new System.Windows.Forms.Button();
            this.btnBallon = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TV)).BeginInit();
            this.SuspendLayout();
            // 
            // TV
            // 
            this.TV.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.TV.Location = new System.Drawing.Point(13, 13);
            this.TV.Name = "TV";
            this.TV.Size = new System.Drawing.Size(785, 420);
            this.TV.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TV.TabIndex = 0;
            this.TV.TabStop = false;
            // 
            // timerImage
            // 
            this.timerImage.Interval = 200;
            // 
            // btnEffacer
            // 
            this.btnEffacer.Location = new System.Drawing.Point(10, 475);
            this.btnEffacer.Name = "btnEffacer";
            this.btnEffacer.Size = new System.Drawing.Size(389, 23);
            this.btnEffacer.TabIndex = 10;
            this.btnEffacer.Text = "Effacer Tout";
            this.btnEffacer.UseVisualStyleBackColor = true;
            this.btnEffacer.Click += new System.EventHandler(this.btnEffacer_Click);
            // 
            // btnStopDeplacerCTick
            // 
            this.btnStopDeplacerCTick.Enabled = false;
            this.btnStopDeplacerCTick.Location = new System.Drawing.Point(405, 475);
            this.btnStopDeplacerCTick.Name = "btnStopDeplacerCTick";
            this.btnStopDeplacerCTick.Size = new System.Drawing.Size(387, 23);
            this.btnStopDeplacerCTick.TabIndex = 9;
            this.btnStopDeplacerCTick.Text = "Stop Tick";
            this.btnStopDeplacerCTick.UseVisualStyleBackColor = true;
            // 
            // btnCreationCarrosse
            // 
            this.btnCreationCarrosse.Location = new System.Drawing.Point(13, 439);
            this.btnCreationCarrosse.Name = "btnCreationCarrosse";
            this.btnCreationCarrosse.Size = new System.Drawing.Size(782, 23);
            this.btnCreationCarrosse.TabIndex = 11;
            this.btnCreationCarrosse.Text = "Creer Carrosse";
            this.btnCreationCarrosse.UseVisualStyleBackColor = true;
            this.btnCreationCarrosse.Click += new System.EventHandler(this.btnCreationCarrosse_Click);
            // 
            // cHomme
            // 
            this.cHomme.Location = new System.Drawing.Point(10, 523);
            this.cHomme.Margin = new System.Windows.Forms.Padding(2);
            this.cHomme.Name = "cHomme";
            this.cHomme.Size = new System.Drawing.Size(175, 43);
            this.cHomme.TabIndex = 12;
            this.cHomme.Text = "Homme";
            this.cHomme.UseVisualStyleBackColor = true;
            this.cHomme.Click += new System.EventHandler(this.cHomme_Click);
            // 
            // btnMarcher
            // 
            this.btnMarcher.Location = new System.Drawing.Point(253, 523);
            this.btnMarcher.Margin = new System.Windows.Forms.Padding(2);
            this.btnMarcher.Name = "btnMarcher";
            this.btnMarcher.Size = new System.Drawing.Size(147, 43);
            this.btnMarcher.TabIndex = 13;
            this.btnMarcher.Text = "Marcher";
            this.btnMarcher.UseVisualStyleBackColor = true;
            this.btnMarcher.Click += new System.EventHandler(this.btnMarcher_Click_1);
            // 
            // btnJouer
            // 
            this.btnJouer.Location = new System.Drawing.Point(405, 523);
            this.btnJouer.Margin = new System.Windows.Forms.Padding(2);
            this.btnJouer.Name = "btnJouer";
            this.btnJouer.Size = new System.Drawing.Size(149, 43);
            this.btnJouer.TabIndex = 14;
            this.btnJouer.Text = "Jouer";
            this.btnJouer.UseVisualStyleBackColor = true;
            // 
            // btnBallon
            // 
            this.btnBallon.Location = new System.Drawing.Point(648, 523);
            this.btnBallon.Margin = new System.Windows.Forms.Padding(2);
            this.btnBallon.Name = "btnBallon";
            this.btnBallon.Size = new System.Drawing.Size(136, 43);
            this.btnBallon.TabIndex = 15;
            this.btnBallon.Text = "Ballon";
            this.btnBallon.UseVisualStyleBackColor = true;
            this.btnBallon.Click += new System.EventHandler(this.btnBallon_Click);
            // 
            // EcranAccueil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(807, 618);
            this.Controls.Add(this.TV);
            this.Controls.Add(this.btnBallon);
            this.Controls.Add(this.btnJouer);
            this.Controls.Add(this.btnMarcher);
            this.Controls.Add(this.cHomme);
            this.Controls.Add(this.btnCreationCarrosse);
            this.Controls.Add(this.btnEffacer);
            this.Controls.Add(this.btnStopDeplacerCTick);
            this.Name = "EcranAccueil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Dessins Animés";
            ((System.ComponentModel.ISupportInitialize)(this.TV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox TV;
        private System.Windows.Forms.Timer timerImage;
        private System.Windows.Forms.Button btnEffacer;
        private System.Windows.Forms.Button btnStopDeplacerCTick;
        private System.Windows.Forms.Button btnCreationCarrosse;
        private System.Windows.Forms.Button cHomme;
        private System.Windows.Forms.Button btnMarcher;
        private System.Windows.Forms.Button btnJouer;
        private System.Windows.Forms.Button btnBallon;
    }
}

