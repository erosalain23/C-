﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Carrosse
{
    class MaJambe : MonRecTournant
    {
        #region Données membres
        //private bool _Remplir = true;
        //private int _Hauteur = 1;
        //private int _Longueur = 1;
        private MonRecTournant jambe,pied;
        #endregion

        #region Constructeurs
        public MaJambe(PictureBox hebergeur, int xsg, int ysg, int longueur, int hauteur, double angle,Color crayon) : base(hebergeur, xsg, ysg, longueur, hauteur )
        {
            this.jambe = new MonRecTournant(hebergeur, CID.X - longueur, CID.Y+5, longueur-4, hauteur-6, angle, Color.Chocolate,Color.Black);
            this.pied = new MonRecTournant(hebergeur, CID.X - longueur, CID.Y + hauteur, longueur + 6, hauteur / 7, angle, Color.DarkGreen,Color.Black);
        }
  
        #endregion
        #region Méthodes
        public void Bouger(int deplX, int deplY, double ah, double ab)
        {
            base.Bouger(deplX, deplY, ah);
            this.jambe.X = base.CIM.X;
            this.jambe.Y = base.CIM.Y;
            jambe.Bouger(0, 0, ab);
            jambe.Bouger(base.CIM.X - jambe.CSM.X, base.CIM.Y - jambe.CSM.Y,0);
            this.pied.X = this.jambe.CIM.X;
            this.pied.Y = this.jambe.CIM.Y;
            this.pied.Bouger(0,0,ab);
            pied.Bouger(jambe.CIM.X - pied.CSG.X, jambe.CIM.Y - pied.CSG.Y, 0);

        }

        public new void Cacher(IntPtr handle)
        {
            base.Cacher(handle);
            this.jambe.Cacher(handle);
            this.pied.Cacher(handle);
        }

        public new void Afficher(IntPtr handle)
        {
            this.jambe.Afficher(handle);
            base.Afficher(handle);
            this.pied.Afficher(handle);
        } 
        #endregion
    }

}
