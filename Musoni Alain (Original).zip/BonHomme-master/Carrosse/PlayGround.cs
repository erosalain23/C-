﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
namespace Carrosse
{
    class PlayGround:MonRecTournant
    {
        private MonRecTournant _ground,_stick;
        private MonCercle _sun,cloudPartT,cloudPartL,cloudPartR,cloudPartB;

        #region constructor
        public PlayGround(PictureBox hebergeur, int xsg, int ysg, int longueur, int hauteur, double angle, Color crayon, Color pot) : base(hebergeur, xsg, ysg, longueur, hauteur, angle, crayon, pot)
        {
            this._ground = new MonRecTournant(hebergeur, xsg/50 , (ysg+hauteur+40)*2 , longueur*20 , hauteur/2, Angle, Color.Coral, Color.White);
            this._sun = new MonCercle(hebergeur, (xsg + longueur+30)*3, ysg / 12, hauteur / 2, Color.Yellow, Color.Yellow);
            Cloud1(hebergeur, xsg, ysg, longueur, hauteur, crayon, pot);
            Cloud2(hebergeur, xsg, ysg, longueur, hauteur, crayon, pot);
            Cloud3(hebergeur, xsg, ysg, longueur, hauteur, crayon, pot);
            this._stick = new MonRecTournant(hebergeur, (xsg+longueur)*3 , (ysg+hauteur+10)*2 , longueur/5 , hauteur-20, Angle, Color.Coral, Color.White);
        }
        #endregion
        #region Methodes
        public new void Bouger(int deplX, int deplY)
        {
            //Déplacement
            base.Bouger(deplX, deplY);
            this._ground.Bouger(0, 0);
            this._stick.Bouger(deplX, deplY);
            this._sun.Bouger(deplX, deplY);
            this.cloudPartT.Bouger(deplX, deplY);
            this.cloudPartL.Bouger(deplX, deplY);
            this.cloudPartR.Bouger(deplX, deplY);
            this.cloudPartB.Bouger(deplX, deplY);
        }

        public new void Cacher(IntPtr handle)
        {
            base.Cacher(handle);
            this._ground.Cacher(handle);
            this._stick.Cacher(handle);
            this._sun.Cacher(handle);
            this.cloudPartT.Cacher(handle);
            this.cloudPartL.Cacher(handle);
            this.cloudPartR.Cacher(handle);
            this.cloudPartB.Cacher(handle);
        }

        public new void Afficher(IntPtr handle)
        {
            //base.Afficher(handle);
            this._ground.Afficher(handle);
            this._stick.Afficher(handle);
            this._sun.Afficher(handle);
            this.cloudPartT.Afficher(handle);
            this.cloudPartL.Afficher(handle);
            this.cloudPartR.Afficher(handle);
            this.cloudPartB.Afficher(handle);

        }
        #endregion
        public void Cloud1(PictureBox hebergeur, int xsg, int ysg, int longueur, int hauteur, Color crayon, Color pot)
        {
            this.cloudPartT = new MonCercle(hebergeur, (xsg + longueur) * 2, ysg / 8, hauteur / 2, Color.White, Color.White);
            this.cloudPartL = new MonCercle(hebergeur, (xsg + longueur - 20) * 2, ysg - 25, hauteur / 2, Color.White, Color.White);
            this.cloudPartR = new MonCercle(hebergeur, (xsg + longueur + 20) * 2, ysg - 25, hauteur / 2, Color.White, Color.White);
            this.cloudPartB = new MonCercle(hebergeur, (xsg + longueur) * 2, ysg - 8, hauteur / 2, Color.White, Color.White);
        }
        public void Cloud2(PictureBox hebergeur, int xsg, int ysg, int longueur, int hauteur, Color crayon, Color pot)
        {
            this.cloudPartT = new MonCercle(hebergeur, (xsg + longueur) , ysg / 8, hauteur / 2, Color.White, Color.White);
            this.cloudPartL = new MonCercle(hebergeur, (xsg + longueur - 10) * 2, ysg - 25, hauteur / 2, Color.White, Color.White);
            this.cloudPartR = new MonCercle(hebergeur, (xsg + longueur + 10) * 2, ysg - 25, hauteur / 2, Color.White, Color.White);
            this.cloudPartB = new MonCercle(hebergeur, (xsg + longueur) , ysg - 8, hauteur / 2, Color.White, Color.White);
        }
        public void Cloud3(PictureBox hebergeur, int xsg, int ysg, int longueur, int hauteur, Color crayon, Color pot)
        {
            this.cloudPartT = new MonCercle(hebergeur, (xsg + longueur) * 2, ysg / 8, hauteur / 2, Color.White, Color.White);
            this.cloudPartL = new MonCercle(hebergeur, (xsg + longueur - 20) * 2, ysg - 25, hauteur / 2, Color.White, Color.White);
            this.cloudPartR = new MonCercle(hebergeur, (xsg + longueur + 20) * 2, ysg - 25, hauteur / 2, Color.White, Color.White);
            this.cloudPartB = new MonCercle(hebergeur, (xsg + longueur) * 2, ysg - 8, hauteur / 2, Color.White, Color.White);
        }

    }
}
